# -*- coding: utf-8 -*-
from . import hr_employee_base 
from . import hr_employee
from . import hr_payslip

from . import hr_contract
from . import tablas_nomina

#Fong descomentado
from . import res_company

from . import hr_payslip_run 
from . import res_bank
from . import horas_extras
from . import hr_work_entry