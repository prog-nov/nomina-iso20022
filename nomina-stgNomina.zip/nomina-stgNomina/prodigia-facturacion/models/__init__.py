# -*- coding: utf-8 -*-
from . import account_invoice_prodigia
from . import account_payment_prodigia
from . import res_company
from . import res_config_settings